console.log("Hallo Welt!");
//# sourceMappingURL=script.js.map